import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class EmployeelistserviceService {

  constructor(private http : HttpClient) { }
  public employeesList = [];

  getEmployeeList(){
    const url = "assets/metadata/employeelist.json";
    return this.http.get(url);
  }
}
