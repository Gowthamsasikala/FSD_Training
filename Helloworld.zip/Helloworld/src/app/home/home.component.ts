import { Component, OnInit, OnChanges, Input ,Output,EventEmitter} from '@angular/core';
import { EmployeelistserviceService } from '../employeelistservice.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  constructor(private service :EmployeelistserviceService){
console.log("hi");
  }
  public userName ;
  public sums = 12;

  public isRequired = false;
  public color = 'black';
  public employeesList:any; // Array of Object
    @Input()
    public name ;

    @Output()
   public sendMessage = new EventEmitter();

  public myName = "GOWTHAM purushoth";

  ngOnInit(): void {
    console.log("ngOnit");
    this.service.getEmployeeList().subscribe(data =>{
      this.employeesList = data;
      console.log(this.employeesList);
    }) // array of object
   
  }


  abc(){
  var sum = 10; // local variable

  var b = (sum == 10) ? 2 : 3;

  console.log(this.userName); // global vari
  
  }

a(){
 this.sendMessage.emit('hi i am from home component');
}

}
