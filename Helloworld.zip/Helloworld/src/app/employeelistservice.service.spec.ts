import { TestBed } from '@angular/core/testing';

import { EmployeelistserviceService } from './employeelistservice.service';

describe('EmployeelistserviceService', () => {
  let service: EmployeelistserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeelistserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
