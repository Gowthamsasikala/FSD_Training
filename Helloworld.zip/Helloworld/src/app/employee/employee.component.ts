import { Component, OnInit } from '@angular/core';
import { EmployeelistserviceService } from '../employeelistservice.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private service : EmployeelistserviceService) { }
  public employeesList :any; // Array of Object
  

  ngOnInit(): void {
  this.service.getEmployeeList().subscribe(data =>{
    this.employeesList = data;
  }) // array of object
    
   
  }



  }


